AMNS FAULT FINDER — ANDROID APK BUILD PACKAGE

IMPORTANT
This ZIP contains Android project source files. It is not a ready-to-install APK. The APK must be built using GitHub Actions or Android Studio.

BUILD USING GITHUB ON A MOBILE PHONE
1. Sign in to GitHub and open your repository (for example, AMNS-Fault-Finder).
2. Upload the CONTENTS of the folder AMNS_Fault_Finder_Mobile_Project to the repository root. Do not upload this ZIP as a single file.
3. Keep the folder structure exactly as supplied. The repository root should contain app/, .github/, build.gradle, settings.gradle, and gradle.properties.
4. Commit the uploaded files to the main branch.
5. Open the repository's Actions tab.
6. Select the workflow named Build AMNS Fault Finder APK. If it does not run automatically, open the workflow and choose Run workflow.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run and find Artifacts. Download the APK artifact ZIP.
9. Extract the artifact ZIP on your phone and install the APK. Android may ask you to allow installation from your browser or file manager. Only proceed if you trust the file and understand the security prompt.

MOBILE UPLOAD TIP
GitHub's browser uploader may not upload folders reliably on every phone. If you cannot upload the folder structure, use GitHub's web editor to create/upload the files while preserving their exact paths, or use a computer. Uploading only the ZIP will not trigger an APK build.

LIMITATIONS
- This package builds the HTML dashboard into a WebView Android app.
- Data saved in local storage is stored separately on each device; it is not automatically synchronized between coworkers.
- Test the app and its download/export features before relying on it for work.
- A client-side admin password is not secure for confidential access.
